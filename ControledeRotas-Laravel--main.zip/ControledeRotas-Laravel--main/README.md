# ControledeRotas-Laravel-
Projeto desenvolvido em aula para aprendermos a ter o controle de rotas usando o framework Laravel.
